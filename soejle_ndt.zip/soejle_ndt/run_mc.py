"""Monte Carlo-følsomhedsanalyse af NDT-parametrene.

    python run_mc.py
Ret PARAMS, N_SIM og SEED herunder. Resten af modellen (geometri, laster) står i soejle_ndt/model.py.
Resultater i ./resultater (overskrives). Luk Excel-filen før kørsel.
"""
from pathlib import Path

import pandas as pd

from soejle_ndt.model import Model
from soejle_ndt import montecarlo as mc, plotting
from main import main as deterministic

# ---------------------------------------------------------------------------
# NDT-parametre: centralværdi = målt/estimeret værdi, spredning = måleusikkerhed.
# VÆRDIERNE ER EKSEMPLER og skal begrundes med kalibrering (DS/EN 13791, GPR-verifikation,
# producentens nøjagtighed) og litteratur.
# ---------------------------------------------------------------------------
PARAMS = {
    "fck":   {"dist": "lognormal", "mean": 30.0, "std": 4.0},                  # [MPa] RH/UPV + kerner
    "phi_l": {"dist": "normal", "mean": 16.0, "std": 1.5, "lo": 8, "hi": 32},  # [mm] GPR
    "phi_w": {"dist": "normal", "mean": 8.0, "std": 1.0, "lo": 5, "hi": 14},   # [mm] GPR
    "c_nom": {"dist": "normal", "mean": 30.0, "std": 5.0, "lo": 5, "hi": 80},  # [mm] GPR / covermeter
}
# Alternativ for diameter: {"dist": "discrete", "values": [12, 14, 16, 20], "probs": [0.1, 0.2, 0.6, 0.1]}

N_SIM = 1000
SEED = 1


def main():
    out = Path("resultater"); out.mkdir(exist_ok=True)
    m = Model()
    print("Deterministisk reference (centralværdier):")
    base_vals = {k: mc.central(s) for k, s in PARAMS.items()}
    import dataclasses
    deterministic(dataclasses.replace(m, **base_vals), out)
    ref = mc.evaluate(m, base_vals)
    n_lc = len(m.load_cases)
    outputs = [f"LC{i}_U_gov" for i in range(1, n_lc + 1)] + ["U_gov_all"]

    print(f"\nMonte Carlo med {N_SIM} simuleringer ...")
    X, Y, valid = mc.monte_carlo(m, PARAMS, N_SIM, SEED)
    print(f"Gyldige: {int(valid.sum())} / {N_SIM}  (ugyldige = geometrisk umulige varianter)")
    summ = mc.summarize(Y, valid, ref)
    sp = mc.spearman(X, Y, valid, outputs)
    oat_df, _, _ = mc.oat(m, PARAMS, outputs)

    inp = pd.DataFrame([dict(parameter=k, **s) for k, s in PARAMS.items()])
    with pd.ExcelWriter(out / "montecarlo.xlsx") as w:
        inp.to_excel(w, sheet_name="Input", index=False)
        pd.DataFrame([ref]).T.rename(columns={0: "U"}).to_excel(w, sheet_name="Reference")
        summ.to_excel(w, sheet_name="MC_opsummering", index=False)
        sp.pivot(index="parameter", columns="output", values="spearman").to_excel(w, sheet_name="Spearman")
        oat_df.to_excel(w, sheet_name="OAT", index=False)
        pd.concat([X, Y, valid.rename("gyldig")], axis=1).to_excel(w, sheet_name="Alle_traekninger", index=False)

    plotting.histograms(Y, valid, ref, n_lc, out / "mc_histogrammer.png")
    plotting.tornado(oat_df, "U_gov_all", out / "oat_tornado.png")
    plotting.spearman_bars(sp, outputs, out / "mc_spearman.png")
    plotting.scatter(X, Y, valid, "U_gov_all", out / "mc_scatter.png")
    plotting.convergence(*mc.convergence(Y, valid, "U_gov_all"), out / "mc_konvergens.png")

    pd.set_option("display.width", 160)
    print("\nOpsummering:")
    print(summ.round(3).to_string(index=False))
    print("\nSpearman:")
    print(sp.pivot(index="parameter", columns="output", values="spearman").round(3))
    print(f"\nResultater gemt i {out.resolve()}")


if __name__ == "__main__":
    main()
