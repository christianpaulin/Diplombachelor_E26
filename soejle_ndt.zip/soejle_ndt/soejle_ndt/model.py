"""INPUT: tværsnit, materialer, lastsager og indstillinger.

Koordinater (EC2 fig. 5.8), origo i betontværsnittets tyngdepunkt:
  y = vandret akse langs bredden b,  z = lodret akse langs højden h.
  "Top" = siden z = +h/2, "bund" = siden z = -h/2.
  M_y = moment om y-aksen (bøjning over højden h). Positivt M_y giver tryk i top.
  M_z = moment om z-aksen (bøjning over bredden b). Positivt M_z giver tryk på siden y = +b/2.
  e_z [mm] = excentricitet i z-retning  -> M_y = N*e_z.   q_z [kN/m] = tværlast i z-retning -> M_y.
  e_y [mm] = excentricitet i y-retning  -> M_z = N*e_y.   q_y [kN/m] = tværlast i y-retning -> M_z.
Fortegn: tryk positivt. Enheder: mm, MPa, kN, kNm, kN/m.

Søjlen er simpelt understøttet (l0 = L). Excentriciteten e er ens i top og bund (konstant 1. ordens moment).
Alle værdier er EKSEMPLER - ret dem til jeres referencesøjle.
"""
from dataclasses import dataclass, field


@dataclass
class LoadCase:
    name: str
    N: float = 0.0       # [kN] regningsmæssig normalkraft (tryk +)
    e_y: float = 0.0     # [mm]
    e_z: float = 0.0     # [mm]
    q_y: float = 0.0     # [kN/m]
    q_z: float = 0.0     # [kN/m]
    phi_ef: float | None = None   # effektivt krybetal for netop denne lastsag (None = Model.phi_ef)


@dataclass
class Model:
    # ---------------- Geometri [mm] ----------------
    b: float = 300.0          # bredde (y)
    h: float = 300.0          # højde (z)
    L: float = 4000.0         # søjlelængde = knæklængde l0 (simpelt understøttet)

    # ---------------- Armering ----------------
    phi_l: float = 16.0       # længdearmeringens diameter (ens for alle stænger)  [MC-parameter]
    n_top: int = 3            # antal stænger i top (inkl. hjørner)
    n_bot: int = 3            # antal stænger i bund (inkl. hjørner)
    n_side: int = 0           # ekstra stænger pr. side mellem top og bund (0 = kun top/bund)
    phi_w: float = 8.0        # bøjlediameter                                      [MC-parameter]
    s_w: float = 200.0        # bøjleafstand
    n_legs_z: int = 2         # antal bøjlesnit, der optager forskydning i z-retning (lodrette ben)
    n_legs_y: int = 2         # antal bøjlesnit, der optager forskydning i y-retning (vandrette ben)
    c_nom: float = 30.0       # dæklag til bøjle                                   [MC-parameter]

    # ---------------- Materialer ----------------
    fck: float = 30.0         # [MPa]                                              [MC-parameter]
    fyk: float = 550.0        # længdearmering [MPa]
    fywk: float = 550.0       # bøjler [MPa]
    Es: float = 200_000.0
    eps_ud: float = 0.045     # 0,9*eps_uk, klasse B (3.2.7(2)); vandret øvre gren

    # Partialkoefficienter - EC2 anbefalede værdier. DK NA SKAL TJEKKES.
    gamma_c: float = 1.5
    gamma_s: float = 1.15
    gamma_cE: float = 1.2     # 5.8.6(3)
    alpha_cc: float = 1.0

    # ---------------- 2. orden (5.8.7 nominel stivhed) ----------------
    phi_ef: float = 1.0       # effektivt krybetal (5.8.4) - skal bestemmes for lastens langtidsandel
    theta_0: float = 1 / 200  # 5.2(5)
    apply_e0_min: bool = True # 6.1(4): e0 >= max(h/30; 20 mm) i hver retning
    ignore_2nd_below_lim: bool = True  # 5.8.2(6): 2. orden negligeres hvis lambda < lambda_lim

    # ---------------- Forskydning (6.2) ----------------
    cot_theta_max: float = 2.5   # 6.2.3(2): 1 <= cot(theta) <= 2,5

    # ---------------- Lastsager ----------------
    load_cases: list = field(default_factory=lambda: [
        LoadCase("LC1: N med excentricitet", N=900.0, e_z=30.0, e_y=10.0),
        LoadCase("LC2: N + excentricitet + tværlast", N=700.0, e_z=30.0, e_y=10.0, q_z=8.0, q_y=3.0),
        LoadCase("LC3: kun tværlast (bjælke)", N=0.0, q_z=20.0),
    ])

    # ---------------- Numerik ----------------
    n_fib: int = 40           # betonfibre i hver retning
    n_theta: int = 72         # nullinjeretninger i My-Mz-konturen
