"""Forskydning EC2 6.2.2 (uden forskydningsarmering) og 6.2.3 (med bøjler, lodrette bøjler alpha = 90°)."""
import numpy as np


def shear_capacity(m, sec, axis, N, M_sign):
    """V_Rd [kN] for forskydning, der hører til M_y ("y": kraft i z-retning) eller M_z ("z").

    M_sign angiver momentets fortegn, så trækarmeringen (A_sl) vælges på den trukne side.
    """
    a = sec.edge_dist()
    if axis == "y":                     # forskydning i z-retning: bw = b, d = h - a
        bw, d = m.b, m.h - a
        bars = sec.zs < 0 if M_sign >= 0 else sec.zs > 0       # tryk i top -> træk i bund
        n_legs = m.n_legs_z
    else:                               # forskydning i y-retning: bw = h, d = b - a
        bw, d = m.h, m.b - a
        bars = sec.ys < 0 if M_sign >= 0 else sec.ys > 0
        n_legs = m.n_legs_y
    # Kun stængerne i den yderste række på trækside
    coord = sec.zs if axis == "y" else sec.ys
    edge = coord[bars].min() if M_sign >= 0 else coord[bars].max()
    Asl = sec.As_bar * np.sum(np.isclose(coord, edge))

    fck, fcd = m.fck, sec.conc.fcd
    sig_cp = min(max(N, 0.0) * 1e3 / sec.Ac, 0.2 * fcd)
    k = min(1 + np.sqrt(200 / d), 2.0)
    rho_l = min(Asl / (bw * d), 0.02)
    C_Rdc, k1 = 0.18 / m.gamma_c, 0.15
    v_min = 0.035 * k ** 1.5 * np.sqrt(fck)
    V_Rdc = max(C_Rdc * k * (100 * rho_l * fck) ** (1 / 3) + k1 * sig_cp, v_min + k1 * sig_cp) * bw * d

    # Med bøjler (6.8), (6.9)
    Asw = n_legs * np.pi * m.phi_w ** 2 / 4
    z = 0.9 * d
    fywd = m.fywk / m.gamma_s
    nu1 = 0.6 * (1 - fck / 250)
    r = sig_cp / fcd
    alpha_cw = 1 + r if r <= 0.25 else (1.25 if r <= 0.5 else 2.5 * (1 - r))
    cot = np.linspace(1.0, m.cot_theta_max, 61)
    V_s = Asw / m.s_w * z * fywd * cot
    V_max = alpha_cw * bw * z * nu1 * fcd / (cot + 1 / cot)
    V_eff = np.minimum(V_s, V_max)
    i = int(np.argmax(V_eff))
    V_Rds = V_eff[i]
    V_Rd = max(V_Rdc, V_Rds)
    return V_Rd / 1e3, dict(V_Rdc=V_Rdc / 1e3, V_Rds=V_Rds / 1e3, V_Rdmax=V_max[i] / 1e3,
                            cot_theta=cot[i], d=d, bw=bw, rho_l=rho_l, k=k, sig_cp=sig_cp, Asw=Asw)


def shear_force(m, lc, axis):
    """V_Ed ved understøtning [kN] = q L / 2."""
    q = lc.q_z if axis == "y" else lc.q_y
    return abs(q) * m.L / 1e3 / 2
