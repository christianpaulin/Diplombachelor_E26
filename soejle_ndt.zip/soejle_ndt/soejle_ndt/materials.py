"""Materialer: beton parabel-rektangel (EC2 3.1.7, (3.17), tabel 3.1) og bilineært stål med vandret gren."""
import numpy as np


class Concrete:
    def __init__(self, fck, gamma_c=1.5, alpha_cc=1.0, gamma_cE=1.2):
        self.fck = fck
        self.fcd = alpha_cc * fck / gamma_c
        self.fcm = fck + 8.0
        self.Ecm = 22_000.0 * (self.fcm / 10.0) ** 0.3          # [MPa], tabel 3.1
        self.Ecd = self.Ecm / gamma_cE                            # 5.8.6(3)
        if fck <= 50:
            self.eps_c2, self.eps_cu2, self.n = 2.0e-3, 3.5e-3, 2.0
        else:
            self.eps_c2 = (2.0 + 0.085 * (fck - 50) ** 0.53) * 1e-3
            self.eps_cu2 = (2.6 + 35 * ((90 - fck) / 100) ** 4) * 1e-3
            self.n = 1.4 + 23.4 * ((90 - fck) / 100) ** 4

    def stress(self, eps):
        """Trykspænding (positiv) for tøjning eps (tryk positiv). Ingen trækstyrke."""
        e = np.clip(eps, 0.0, self.eps_c2)
        return self.fcd * (1.0 - (1.0 - e / self.eps_c2) ** self.n)


class Steel:
    def __init__(self, fyk, gamma_s=1.15, Es=200_000.0, eps_ud=0.045):
        self.fyd = fyk / gamma_s
        self.Es = Es
        self.eps_ud = eps_ud

    def stress(self, eps):
        return np.clip(self.Es * eps, -self.fyd, self.fyd)
