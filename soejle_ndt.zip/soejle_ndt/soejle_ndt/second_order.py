"""Imperfektion (5.2), slankhedsgrænse (5.8.3.1) og 2. orden med nominel stivhed (5.8.7).

En retning ("y" eller "z") er momentets akse:
  "y": M_y, bøjning over h, udbøjning i z-retning, excentricitet e_z, tværlast q_z.
  "z": M_z, bøjning over b, udbøjning i y-retning, excentricitet e_y, tværlast q_y.
"""
import numpy as np


def dims(m, axis):
    """(tværsnitsdimension i bøjningsretningen, bredde vinkelret) [mm]."""
    return (m.h, m.b) if axis == "y" else (m.b, m.h)


def imperfection(m):
    """e_i = theta_i * l0 / 2 [mm], theta_i = theta_0 * alpha_h * alpha_m, alpha_m = 1 (5.2(5), (7))."""
    alpha_h = min(1.0, max(2 / 3, 2 / np.sqrt(m.L / 1000)))
    theta_i = m.theta_0 * alpha_h
    return theta_i * m.L / 2, theta_i


def slenderness(m, sec, axis):
    hd, _ = dims(m, axis)
    i = hd / np.sqrt(12)
    return m.L / i


def lambda_lim(m, sec, N, phi_ef):
    """5.8.3.1 (5.13N). rm = 1 (ens endeexcentricitet / overvejende tværlast) -> C = 0,7."""
    if N <= 0:
        return np.inf
    A = 1 / (1 + 0.2 * phi_ef)
    omega = sec.As * sec.steel.fyd / (sec.Ac * sec.conc.fcd)
    B = np.sqrt(1 + 2 * omega)
    C = 0.7
    n = N * 1e3 / (sec.Ac * sec.conc.fcd)
    return 20 * A * B * C / np.sqrt(n)


def nominal_stiffness(m, sec, axis, N, phi_ef):
    """EI [Nmm^2] efter (5.21) med (5.22): Ks = 1, Kc = k1*k2/(1+phi_ef). Kræver rho >= 0,002."""
    hd, bd = dims(m, axis)
    Ic = bd * hd ** 3 / 12
    Is = sec.I_s(axis)
    lam = slenderness(m, sec, axis)
    n = max(N, 0.0) * 1e3 / (sec.Ac * sec.conc.fcd)
    k1 = np.sqrt(m.fck / 20)
    k2 = min(n * lam / 170, 0.20)
    Kc = k1 * k2 / (1 + phi_ef)
    EI = Kc * sec.conc.Ecd * Ic + 1.0 * m.Es * Is
    return EI, dict(Ic=Ic, Is=Is, k1=k1, k2=k2, Kc=Kc, n=n, rho=sec.As / sec.Ac)


def design_moment(m, sec, lc, axis, with_imperfection, phi_ef):
    """Regningsmæssigt moment midt på søjlen [kNm] inkl. 2. orden. Returnerer (M_Ed, detaljer)."""
    N = lc.N
    e = lc.e_z if axis == "y" else lc.e_y
    q = lc.q_z if axis == "y" else lc.q_y
    hd, _ = dims(m, axis)
    M_e = N * e / 1e3                         # konstant moment [kNm]
    M_q = q * (m.L / 1e3) ** 2 / 8            # parabolsk moment [kNm]
    e_i, theta_i = imperfection(m)
    s = np.sign(M_e + M_q) or 1.0             # imperfektion virker ugunstigt
    M_i = s * N * e_i / 1e3 if (with_imperfection and N > 0) else 0.0
    M0 = M_e + M_q + M_i

    lam = slenderness(m, sec, axis)
    lam_lim = lambda_lim(m, sec, N, phi_ef)
    d = dict(N=N, M_e=M_e, M_q=M_q, M_i=M_i, M0=M0, e_i=e_i, theta_i=theta_i,
             lam=lam, lam_lim=lam_lim, EI=np.nan, NB=np.nan, amp_e=1.0, amp_q=1.0, amp_i=1.0,
             second_order=False, unstable=False, e0_governs=False)

    if N > 0 and not (m.ignore_2nd_below_lim and lam < lam_lim):
        EI, kd = nominal_stiffness(m, sec, axis, N, phi_ef)
        NB = np.pi ** 2 * EI / m.L ** 2 / 1e3          # [kN]
        d.update(EI=EI, NB=NB, second_order=True, **kd)
        if N >= NB:
            d["unstable"] = True
            return np.inf * s, d
        f = 1 / (NB / N - 1)
        # (5.28) pr. momentkomponent: beta = pi^2/c0, c0 = 8 (konstant), 9,6 (parabolsk), pi^2 (sinus)
        d["amp_e"] = 1 + (np.pi ** 2 / 8) * f
        d["amp_q"] = 1 + (np.pi ** 2 / 9.6) * f
        d["amp_i"] = 1 + 1.0 * f
    M_Ed = M_e * d["amp_e"] + M_q * d["amp_q"] + M_i * d["amp_i"]

    if m.apply_e0_min and N > 0 and with_imperfection:
        e0 = max(hd / 30, 20.0)
        d["e0"] = e0
        if abs(M_Ed) < N * e0 / 1e3:
            M_Ed = (np.sign(M_Ed) or 1.0) * N * e0 / 1e3
            d["e0_governs"] = True
    d["M_Ed"] = M_Ed
    return M_Ed, d
