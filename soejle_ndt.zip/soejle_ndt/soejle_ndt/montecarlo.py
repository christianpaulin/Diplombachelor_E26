"""Monte Carlo og følsomhedsanalyse af NDT-parametre.

Fordelinger (dict i run_mc.py):
  {"dist": "normal",    "mean": μ, "std": σ, "lo": .., "hi": ..}   (lo/hi valgfri trunkering)
  {"dist": "lognormal", "mean": μ, "std": σ}                       (μ, σ for selve variablen)
  {"dist": "uniform",   "lo": a, "hi": b}
  {"dist": "discrete",  "values": [...], "probs": [...]}
  {"dist": "fixed",     "value": v}
"mean"/"value" er den målte/estimerede værdi, "std" er måleudstyrets/estimatets usikkerhed.
"""
import dataclasses
import time

import numpy as np
import pandas as pd
from scipy import stats

from .checks import run, CHECKS


# ------------------------------------------------------------------ fordelinger
def sample(spec, n, rng):
    d = spec["dist"]
    if d == "fixed":
        return np.full(n, float(spec["value"]))
    if d == "normal":
        lo, hi = spec.get("lo", -np.inf), spec.get("hi", np.inf)
        a, b = (lo - spec["mean"]) / spec["std"], (hi - spec["mean"]) / spec["std"]
        return stats.truncnorm.rvs(a, b, loc=spec["mean"], scale=spec["std"], size=n, random_state=rng)
    if d == "lognormal":
        mu, sd = spec["mean"], spec["std"]
        s2 = np.log(1 + (sd / mu) ** 2)
        return rng.lognormal(np.log(mu) - s2 / 2, np.sqrt(s2), n)
    if d == "uniform":
        return rng.uniform(spec["lo"], spec["hi"], n)
    if d == "discrete":
        p = np.asarray(spec.get("probs", np.ones(len(spec["values"]))), float)
        return rng.choice(np.asarray(spec["values"], float), size=n, p=p / p.sum())
    raise ValueError(f"Ukendt fordeling: {d}")


def central(spec):
    """Centralværdi (bruges til OAT og som 'målt værdi')."""
    if spec["dist"] == "fixed":
        return spec["value"]
    if spec["dist"] == "uniform":
        return 0.5 * (spec["lo"] + spec["hi"])
    if spec["dist"] == "discrete":
        p = np.asarray(spec.get("probs", np.ones(len(spec["values"]))), float)
        return float(np.dot(spec["values"], p / p.sum()))
    return spec["mean"]


def quantile(spec, q):
    """Fraktil q af fordelingen (bruges til OAT-grænser)."""
    d = spec["dist"]
    if d == "fixed":
        return spec["value"]
    if d == "uniform":
        return spec["lo"] + q * (spec["hi"] - spec["lo"])
    if d == "discrete":
        v = np.asarray(spec["values"], float)
        p = np.asarray(spec.get("probs", np.ones(len(v))), float)
        o = np.argsort(v); c = np.cumsum(p[o] / p.sum())
        return float(v[o][np.searchsorted(c, q)])
    if d == "normal":
        lo, hi = spec.get("lo", -np.inf), spec.get("hi", np.inf)
        a, b = (lo - spec["mean"]) / spec["std"], (hi - spec["mean"]) / spec["std"]
        return float(stats.truncnorm.ppf(q, a, b, loc=spec["mean"], scale=spec["std"]))
    if d == "lognormal":
        mu, sd = spec["mean"], spec["std"]
        s2 = np.log(1 + (sd / mu) ** 2)
        return float(stats.lognorm.ppf(q, np.sqrt(s2), scale=np.exp(np.log(mu) - s2 / 2)))


# ------------------------------------------------------------------ evaluering
def evaluate(m, values):
    """Kør alle checks for model m med parameterværdierne i values. Returnerer flad dict eller None."""
    try:
        mm = dataclasses.replace(m, **values)
        _, res = run(mm)
    except ValueError:
        return None                                         # geometrisk umulig variant
    row = {}
    for i, r in enumerate(res, 1):
        for k in CHECKS + ["U_gov"]:
            row[f"LC{i}_{k}"] = float(r[k])
    row["U_gov_all"] = max(row[f"LC{i}_U_gov"] for i in range(1, len(res) + 1))
    return row


def monte_carlo(m, params, n, seed=1, progress=True):
    rng = np.random.default_rng(seed)
    X = pd.DataFrame({k: sample(s, n, rng) for k, s in params.items()})
    rows, t0 = [], time.time()
    for i, x in X.iterrows():
        r = evaluate(m, x.to_dict())
        rows.append(r if r is not None else {})
        if progress and (i + 1) % max(1, n // 10) == 0:
            print(f"  MC {i + 1}/{n}  ({time.time() - t0:.0f} s)")
    Y = pd.DataFrame(rows, index=X.index)
    valid = Y.notna().all(axis=1) & (len(Y.columns) > 0)
    return X, Y, valid


def summarize(Y, valid, ref):
    Yv = Y[valid]
    out = []
    for c in Y.columns:
        v = Yv[c].replace([np.inf], np.nan)
        out.append(dict(output=c, reference=ref.get(c, np.nan), mean=v.mean(), std=v.std(),
                        p05=v.quantile(0.05), p50=v.quantile(0.5), p95=v.quantile(0.95),
                        max=v.max(), P_U_gt_1=float((Yv[c] > 1).mean()),
                        n_inf=int(np.isinf(Yv[c]).sum())))
    return pd.DataFrame(out)


def spearman(X, Y, valid, outputs):
    rows = []
    for o in outputs:
        y = Y.loc[valid, o].replace([np.inf], 1e9)
        for p in X.columns:
            x = X.loc[valid, p]
            rho = stats.spearmanr(x, y).statistic if x.std() > 0 and y.std() > 0 else 0.0
            rows.append(dict(output=o, parameter=p, spearman=rho))
    return pd.DataFrame(rows)


def oat(m, params, outputs, q_lo=0.05, q_hi=0.95):
    """One-at-a-time: hver parameter til fraktil q_lo og q_hi, de andre i centralværdi."""
    base_vals = {k: central(s) for k, s in params.items()}
    base = evaluate(m, base_vals)
    rows = []
    for p, s in params.items():
        if s["dist"] == "fixed":
            continue
        for lab, q in (("lav", q_lo), ("høj", q_hi)):
            v = dict(base_vals); v[p] = quantile(s, q)
            r = evaluate(m, v)
            for o in outputs:
                rows.append(dict(parameter=p, niveau=lab, vaerdi=v[p], output=o,
                                 U=(r or {}).get(o, np.nan), U_ref=base[o]))
    return pd.DataFrame(rows), base_vals, base


def convergence(Y, valid, col):
    y = Y.loc[valid, col].replace([np.inf], np.nan).dropna().to_numpy()
    n = np.arange(1, len(y) + 1)
    return n, np.cumsum(y) / n, np.cumsum(y > 1) / n
