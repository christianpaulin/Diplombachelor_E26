"""Figurer: tværsnit, M-N-diagrammer, My-Mz-kurver og Monte Carlo-resultater."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .section import Contour

BLUE, RED, GREY = "#1f5fa8", "#d1495b", "#555555"
LC_COLORS = ["#d1495b", "#edae49", "#00798c", "#30638e", "#66a182"]


def _save(fig, path):
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def section(sec, path):
    m = sec.m
    fig, ax = plt.subplots(figsize=(4, 4 * m.h / m.b))
    ax.add_patch(plt.Rectangle((-m.b / 2, -m.h / 2), m.b, m.h, fc="#e6e6e6", ec="k"))
    o = m.c_nom + m.phi_w / 2
    ax.add_patch(plt.Rectangle((-m.b / 2 + o, -m.h / 2 + o), m.b - 2 * o, m.h - 2 * o,
                               fc="none", ec=GREY, lw=1.2))
    for y, z in zip(sec.ys, sec.zs):
        ax.add_patch(plt.Circle((y, z), m.phi_l / 2, color="k"))
    ax.text(0, m.h / 2 + 15, "top", ha="center", fontsize=8)
    ax.set_title(f"{m.b:.0f}x{m.h:.0f}, {len(sec.ys)} Ø{m.phi_l:.0f}, bøjle Ø{m.phi_w:.0f}/{m.s_w:.0f}, "
                 f"c={m.c_nom:.0f}", fontsize=9)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-m.b / 2 - 20, m.b / 2 + 20); ax.set_ylim(-m.h / 2 - 20, m.h / 2 + 35)
    _save(fig, path)


def mn_diagram(sec, results, axis, path):
    """M-N-diagram om y (theta = ±90°) eller z (theta = 0/180°) med lastpunkter inkl. 2. orden."""
    fig, ax = plt.subplots(figsize=(6, 6))
    if axis == "y":
        th_pos, th_neg, idx, lab = np.pi / 2, -np.pi / 2, 1, r"$M_{y}$"
    else:
        th_pos, th_neg, idx, lab = 0.0, np.pi, 2, r"$M_{z}$"
    for th in (th_pos, th_neg):
        r = sec.MN_curve(th, n=601)
        ax.plot(r[idx], r[0], color=BLUE, lw=2)
    ax.plot([], [], color=BLUE, lw=2, label="M-N-bæreevne (6.1)")
    for i, res in enumerate(results):
        if not np.isfinite(res.get("U_gov", np.inf)):
            continue
        d = res["det_" + axis]
        col = LC_COLORS[i % len(LC_COLORS)]
        ax.plot(d["M0"], res["N_Ed"], "o", mfc="white", mec=col, ms=7)
        ax.plot(d["M_Ed"], res["N_Ed"], "o", color=col, ms=7,
                label=f"{res['name'].split(':')[0]}: M0={d['M0']:.1f} → M_Ed={d['M_Ed']:.1f} kNm")
        ax.annotate("", (d["M_Ed"], res["N_Ed"]), (d["M0"], res["N_Ed"]),
                    arrowprops=dict(arrowstyle="->", color=col))
    ax.axhline(0, color="0.7", lw=0.6); ax.axvline(0, color="0.7", lw=0.6)
    ax.set_xlabel(lab + " [kNm]"); ax.set_ylabel("N [kN] (tryk +)")
    ax.set_title(f"M-N-diagram om {axis}-aksen (åben: 1. orden, fyldt: inkl. 2. orden)", fontsize=10)
    ax.grid(alpha=0.3); ax.legend(fontsize=7, loc="upper right")
    _save(fig, path)


def biaxial(sec, results, m, path):
    fig, ax = plt.subplots(figsize=(6.5, 6.5))
    for i, res in enumerate(results):
        if not np.isfinite(res.get("U_gov", np.inf)):
            continue
        col = LC_COLORS[i % len(LC_COLORS)]
        con = Contour(sec, res["N_Ed"], max(144, m.n_theta))
        o = np.argsort(np.arctan2(con.Mz, con.My))
        ax.plot(np.append(con.My[o], con.My[o][0]), np.append(con.Mz[o], con.Mz[o][0]), color=col, lw=1.8)
        b, a = res["biax"], res["a"]
        t = np.linspace(0, 2 * np.pi, 361)
        cy, cz = np.cos(t), np.sin(t)
        Ry = np.where(cy >= 0, con.M_Rdy_pos, con.M_Rdy_neg)
        Rz = np.where(cz >= 0, con.M_Rdz_pos, con.M_Rdz_neg)
        r = ((np.abs(cy) / Ry) ** a + (np.abs(cz) / Rz) ** a) ** (-1 / a)
        ax.plot(r * cy, r * cz, color=col, lw=1.2, ls="--")
        ax.plot(b["M_y"], b["M_z"], "o", color=col, ms=7,
                label=f"{res['name'].split(':')[0]}: N={res['N_Ed']:.0f} kN, U_EC2={b['U']:.2f}, "
                      f"U_eksakt={b['U_exact']:.2f}")
    ax.plot([], [], color="k", lw=1.8, label="Eksakt tværsnitsanalyse")
    ax.plot([], [], color="k", lw=1.2, ls="--", label="EC2 (5.39)")
    ax.axhline(0, color="0.7", lw=0.6); ax.axvline(0, color="0.7", lw=0.6)
    ax.set_xlabel(r"$M_y$ [kNm]"); ax.set_ylabel(r"$M_z$ [kNm]"); ax.set_aspect("equal")
    ax.set_title("Biaksial bøjning ved N_Ed for hver lastsag", fontsize=10)
    ax.grid(alpha=0.3); ax.legend(fontsize=7, loc="lower left")
    _save(fig, path)


# ------------------------------------------------------------------ Monte Carlo
def histograms(Y, valid, ref, n_lc, path):
    fig, axs = plt.subplots(1, n_lc, figsize=(4.2 * n_lc, 3.6), squeeze=False)
    for i in range(n_lc):
        ax = axs[0, i]; c = f"LC{i + 1}_U_gov"
        y = Y.loc[valid, c].replace([np.inf], np.nan).dropna()
        ax.hist(y, bins=40, color=BLUE, alpha=0.8)
        ax.axvline(ref[c], color="k", lw=1.5, label=f"Reference {ref[c]:.3f}")
        ax.axvline(y.quantile(0.95), color=RED, ls="--", label=f"95 %-fraktil {y.quantile(0.95):.3f}")
        ax.axvline(1.0, color=RED, lw=2, label=f"P(U>1) = {(Y.loc[valid, c] > 1).mean():.3f}")
        ax.set_title(f"LC{i + 1}: styrende udnyttelse", fontsize=10); ax.set_xlabel("U")
        ax.legend(fontsize=7)
    _save(fig, path)


def tornado(oat_df, output, path):
    d = oat_df[oat_df.output == output]
    if d.empty:
        return
    U_ref = d.U_ref.iloc[0]
    piv = d.pivot(index="parameter", columns="niveau", values="U")
    vals = d.pivot(index="parameter", columns="niveau", values="vaerdi")
    rng = (piv.max(axis=1) - piv.min(axis=1)).sort_values()
    fig, ax = plt.subplots(figsize=(6.5, 0.6 * len(rng) + 1.5))
    for k, p in enumerate(rng.index):
        for lab, col in (("lav", BLUE), ("høj", RED)):
            u = piv.loc[p, lab]
            ax.barh(k, u - U_ref, left=U_ref, color=col, alpha=0.85)
            ax.text(u, k, f" {vals.loc[p, lab]:.1f}", va="center", fontsize=7,
                    ha="left" if u >= U_ref else "right")
    ax.axvline(U_ref, color="k", lw=1)
    ax.set_yticks(range(len(rng))); ax.set_yticklabels(rng.index)
    from matplotlib.patches import Patch
    ax.set_xlabel(f"{output} (reference {U_ref:.3f})")
    ax.legend(handles=[Patch(color=BLUE, label="Parameter ved 5 %-fraktil"),
                       Patch(color=RED, label="Parameter ved 95 %-fraktil")], fontsize=8)
    ax.set_title("OAT-følsomhed (tal = parameterværdi)", fontsize=10)
    _save(fig, path)


def spearman_bars(sp_df, outputs, path):
    piv = sp_df.pivot(index="parameter", columns="output", values="spearman").reindex(columns=outputs)
    fig, ax = plt.subplots(figsize=(7, 3.8))
    w = 0.8 / len(outputs); x = np.arange(len(piv))
    for j, o in enumerate(outputs):
        ax.bar(x + j * w - 0.4 + w / 2, piv[o], w, label=o, color=LC_COLORS[j % len(LC_COLORS)])
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xticks(x); ax.set_xticklabels(piv.index)
    ax.set_ylabel("Spearman ρ"); ax.set_ylim(-1, 1); ax.grid(alpha=0.3, axis="y")
    ax.set_title("Rangkorrelation mellem NDT-parameter og udnyttelse", fontsize=10)
    ax.legend(fontsize=7)
    _save(fig, path)


def scatter(X, Y, valid, output, path):
    ps = list(X.columns)
    fig, axs = plt.subplots(1, len(ps), figsize=(3.4 * len(ps), 3.2), squeeze=False)
    y = Y.loc[valid, output].replace([np.inf], np.nan)
    for j, p in enumerate(ps):
        ax = axs[0, j]
        ax.scatter(X.loc[valid, p], y, s=4, alpha=0.4, color=BLUE)
        ax.axhline(1, color=RED, lw=1); ax.set_xlabel(p); ax.grid(alpha=0.3)
        if j == 0:
            ax.set_ylabel(output)
    _save(fig, path)


def convergence(n, mean, pf, path):
    fig, ax = plt.subplots(figsize=(6, 3.4))
    ax.plot(n, mean, color=BLUE, label="Middelværdi af U")
    ax2 = ax.twinx(); ax2.plot(n, pf, color=RED, label="P(U > 1)")
    ax.set_xlabel("Antal simuleringer"); ax.set_ylabel("Middel U", color=BLUE); ax2.set_ylabel("P(U>1)", color=RED)
    ax.set_title("Konvergens (styrende udnyttelse, alle lastsager)", fontsize=10); ax.grid(alpha=0.3)
    _save(fig, path)
