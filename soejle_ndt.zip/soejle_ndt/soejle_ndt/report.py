"""Tekstrapport for den deterministiske eftervisning."""
import numpy as np

from .checks import CHECKS, CHECK_TEXT
from .second_order import imperfection


def _f(v, n=2):
    return "∞" if not np.isfinite(v) else f"{v:.{n}f}"


def text(m, sec, results):
    ok = lambda u: "OK" if u <= 1 + 1e-9 else "IKKE OK"
    L = ["EFTERVISNING AF SIMPELT UNDERSTØTTET BETONSØJLE (EN 1992-1-1)", "=" * 66]
    L.append(f"Tværsnit b x h = {m.b:.0f} x {m.h:.0f} mm, L = l0 = {m.L:.0f} mm")
    L.append(f"Længdearmering: {m.n_top} Ø{m.phi_l:.0f} top, {m.n_bot} Ø{m.phi_l:.0f} bund, "
             f"{m.n_side} pr. side  ->  A_s = {sec.As:.0f} mm² (rho = {sec.As / sec.Ac * 100:.2f} %)")
    L.append(f"Bøjler: Ø{m.phi_w:.0f}/{m.s_w:.0f}, {m.n_legs_z} snit (z) / {m.n_legs_y} snit (y). "
             f"Dæklag c_nom = {m.c_nom:.0f} mm, kant-stangcentrum = {sec.edge_dist():.1f} mm")
    L.append(f"Beton: f_ck = {m.fck:.1f}, f_cd = {sec.conc.fcd:.2f}, E_cm = {sec.conc.Ecm:.0f}, "
             f"E_cd = {sec.conc.Ecd:.0f} MPa.  Stål: f_yd = {sec.steel.fyd:.1f} MPa")
    e_i, th = imperfection(m)
    L.append(f"Imperfektion (5.2): theta_i = 1/{1 / th:.0f}, e_i = {e_i:.1f} mm.  phi_ef = {m.phi_ef}")
    if sec.As / sec.Ac < 0.002:
        L.append("ADVARSEL: rho < 0,002 - (5.22) gælder ikke.")
    L.append("")
    for r in results:
        L.append("-" * 66)
        L.append(r["name"])
        lc = next(lc for lc in m.load_cases if lc.name == r["name"])
        L.append(f"  N_Ed = {lc.N:.1f} kN, e_y = {lc.e_y:.1f} mm, e_z = {lc.e_z:.1f} mm, "
                 f"q_y = {lc.q_y:.2f} kN/m, q_z = {lc.q_z:.2f} kN/m")
        if "note" in r:
            L.append("  " + r["note"]); continue
        for ax in ("y", "z"):
            d = r["det_" + ax]
            L.append(f"  Om {ax}: lambda = {d['lam']:.1f}, lambda_lim = {_f(d['lam_lim'], 1)} -> "
                     f"2. orden {'medtaget' if d['second_order'] else 'negligeret'}")
            if d["second_order"]:
                L.append(f"     EI = {d['EI'] / 1e9:.0f} kNm², k1 = {d['k1']:.3f}, k2 = {d['k2']:.3f}, "
                         f"Kc = {d['Kc']:.4f}, N_B = {d['NB']:.0f} kN, N_Ed/N_B = {lc.N / d['NB']:.3f}")
                L.append(f"     Forstørrelse: e {d['amp_e']:.3f}, q {d['amp_q']:.3f}, imperf. {d['amp_i']:.3f}")
            L.append(f"     M0: N*e = {d['M_e']:.2f} + qL²/8 = {d['M_q']:.2f} + N*e_i = {d['M_i']:.2f} "
                     f"= {d['M0']:.2f} kNm  ->  M_Ed = {_f(d['M_Ed'])} kNm"
                     + ("  (e0,min styrer)" if d["e0_governs"] else ""))
        L.append(f"  M_Rdy = {r['M_Rdy']:.1f} kNm, M_Rdz = {r['M_Rdz']:.1f} kNm (ved N_Ed)")
        b = r["biax"]
        c = r["crit_589"]
        L.append(f"  Biaksial: imperfektion i {b['imp']}-momentet, M_y = {b['M_y']:.1f}, M_z = {b['M_z']:.1f} kNm, "
                 f"N_Rd = {r['N_Rd_589']:.0f} kN, a = {r['a']:.3f}")
        L.append(f"     (M_z/M_Rdz)^a + (M_y/M_Rdy)^a = {b['sum']:.3f}; U = sum^(1/a) = {b['U']:.3f}; "
                 f"eksakt U = {b['U_exact']:.3f}")
        L.append(f"     5.8.9(3): slankhed ok = {c['slank_ok']}, e-forhold = "
                 f"{'-' if c['e_ratio'] is None else _f(c['e_ratio'])}, kan undlades = {c['kan_undlades']}")
        for ax, lab in (("y", "z-retning"), ("z", "y-retning")):
            v = r["V_" + ax]
            L.append(f"  Forskydning {lab}: V_Ed = {v['V_Ed']:.1f}, V_Rd,c = {v['V_Rdc']:.1f}, "
                     f"V_Rd,s = {v['V_Rds']:.1f} (cot θ = {v['cot_theta']:.2f}), V_Rd = {v['V_Rd']:.1f} kN")
        L.append("  Udnyttelser:")
        for k in CHECKS:
            L.append(f"     {CHECK_TEXT[k]:<55s} {_f(r[k], 3):>7s}  {ok(r[k])}")
        L.append(f"  STYRENDE: {CHECK_TEXT[r['gov_check']]}  U = {_f(r['U_gov'], 3)}  {ok(r['U_gov'])}")
    L.append("")
    L.append("Antagelser: se README. EC2 anbefalede værdier - DK NA skal tjekkes. Resultater skal kontrolleres fagligt.")
    return "\n".join(L)
