"""Samlet eftervisning pr. lastsag: tværsnit (M-N), 2. orden, biaksial bøjning (5.8.9) og forskydning (6.2)."""
import numpy as np

from .section import Section, Contour
from .second_order import design_moment
from .shear import shear_capacity, shear_force

CHECKS = ["U_N", "U_My", "U_Mz", "U_biax", "U_Vz", "U_Vy"]
CHECK_TEXT = {
    "U_N": "Ren trykbæreevne N_Ed/N_Rd,max (6.1(5))",
    "U_My": "M-N om y inkl. 2. orden (6.1 + 5.8.7)",
    "U_Mz": "M-N om z inkl. 2. orden (6.1 + 5.8.7)",
    "U_biax": "Biaksial bøjning EC2 (5.39), udnyttelse = sum^(1/a)",
    "U_Vz": "Forskydning, kraft i z-retning (6.2)",
    "U_Vy": "Forskydning, kraft i y-retning (6.2)",
}


def exponent_a(N, N_Rd):
    """5.8.9(4): N/N_Rd = 0,1 -> 1,0; 0,7 -> 1,5; 1,0 -> 2,0 (lineær interpolation)."""
    return float(np.interp(N / N_Rd, [0.1, 0.7, 1.0], [1.0, 1.5, 2.0]))


def criteria_589_3(m, lam_y, lam_z, M_y, M_z, N):
    """5.8.9(3). Excentriciteter normeret med tværsnitsmålet i samme retning (tjek mod (5.38b))."""
    slank = (lam_y / lam_z <= 2) and (lam_z / lam_y <= 2)
    if N <= 0 or (M_y == 0 and M_z == 0):
        return dict(slank_ok=slank, e_ratio=None, kan_undlades=False)
    ez, ey = abs(M_y / N) * 1e3 / m.h, abs(M_z / N) * 1e3 / m.b
    ratio = np.inf if ez == 0 else ey / ez
    exc = ratio <= 0.2 or ratio >= 5
    return dict(slank_ok=slank, e_ratio=ratio, kan_undlades=bool(slank and exc))


def run_case(m, sec, lc, contours):
    phi_ef = m.phi_ef if lc.phi_ef is None else lc.phi_ef
    N = lc.N
    N_min, N_max = sec.N_limits()
    out = dict(name=lc.name, N_Ed=N, N_Rd_max=N_max, U_N=max(N, 0) / N_max)
    if not (N_min < N < N_max):
        for k in CHECKS[1:]:
            out[k] = np.inf
        out["U_gov"] = np.inf
        out["note"] = "N_Ed ligger uden for tværsnittets bæreevne"
        return out
    if N not in contours:
        contours[N] = Contour(sec, N, m.n_theta)
    con = contours[N]

    # --- Uniaksialt med imperfektion i den aktuelle retning
    My, dy = design_moment(m, sec, lc, "y", True, phi_ef)
    Mz, dz = design_moment(m, sec, lc, "z", True, phi_ef)
    out.update(det_y=dy, det_z=dz, M_Edy=My, M_Edz=Mz)
    out["M_Rdy"] = con.M_Rdy(np.sign(My) or 1)
    out["M_Rdz"] = con.M_Rdz(np.sign(Mz) or 1)
    out["U_My"] = abs(My) / out["M_Rdy"]
    out["U_Mz"] = abs(Mz) / out["M_Rdz"]

    # --- Biaksialt (5.8.9): imperfektion kun i den mest ugunstige retning (5.8.9(2))
    N_Rd = (sec.Ac * sec.conc.fcd + sec.As * sec.steel.fyd) / 1e3
    a = exponent_a(N, N_Rd)
    best = None
    for imp in ("y", "z"):
        my = design_moment(m, sec, lc, "y", imp == "y", phi_ef)[0]
        mz = design_moment(m, sec, lc, "z", imp == "z", phi_ef)[0]
        Ry, Rz = con.M_Rdy(np.sign(my) or 1), con.M_Rdz(np.sign(mz) or 1)
        s = (abs(mz) / Rz) ** a + (abs(my) / Ry) ** a
        U = s ** (1 / a)
        psi = np.arctan2(mz, my)
        U_ex = np.hypot(my, mz) / float(con.radius(psi)) if np.isfinite(my + mz) else np.inf
        cand = dict(imp=imp, M_y=my, M_z=mz, M_Rdy=Ry, M_Rdz=Rz, sum=s, U=U, U_exact=U_ex)
        if best is None or U > best["U"]:
            best = cand
    out.update(N_Rd_589=N_Rd, a=a, biax=best, U_biax=best["U"],
               crit_589=criteria_589_3(m, dy["lam"], dz["lam"], best["M_y"], best["M_z"], N))

    # --- Forskydning ved understøtning
    for axis, key, Msign in (("y", "U_Vz", np.sign(My) or 1), ("z", "U_Vy", np.sign(Mz) or 1)):
        V_Ed = shear_force(m, lc, axis)
        V_Rd, dv = shear_capacity(m, sec, axis, N, Msign)
        out[key] = V_Ed / V_Rd
        out["V_" + axis] = dict(V_Ed=V_Ed, V_Rd=V_Rd, **dv)

    out["U_gov"] = max(out[k] for k in CHECKS)
    out["gov_check"] = max(CHECKS, key=lambda k: out[k])
    return out


def run(m):
    """Alle lastsager. Returnerer (Section, liste af resultater)."""
    sec = Section(m)
    contours = {}
    return sec, [run_case(m, sec, lc, contours) for lc in m.load_cases]
