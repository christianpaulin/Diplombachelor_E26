"""Fibertværsnit og bæreevne for N + M_y + M_z (EC2 6.1).

Brudtøjningstilstande (EC2 6.1(3), fig. 6.1) i retningen theta, parameter t in [0, 3]:
  t in [0,1]  A: mest trukne stang har -eps_ud, trykranden går fra -eps_ud til eps_cu2
  t in [1,2]  B: trykranden har eps_cu2, mest trukne stang går fra -eps_ud til nul-tøjning i modsat rand
  t in [2,3]  C: drejning om punktet (1 - eps_c2/eps_cu2)*H fra trykranden, til ensformigt eps_c2
N(t) er monoton i t, så en given normalkraft findes ved bisektion (vektoriseret over alle theta).
theta er retningen af den mest trykkede side: theta = +90° giver tryk i top (M_y > 0).
"""
import numpy as np

from .materials import Concrete, Steel


class Section:
    def __init__(self, m):
        self.m = m
        self.conc = Concrete(m.fck, m.gamma_c, m.alpha_cc, m.gamma_cE)
        self.steel = Steel(m.fyk, m.gamma_s, m.Es, m.eps_ud)
        n = m.n_fib
        dy, dz = m.b / n, m.h / n
        yc = -m.b / 2 + dy * (np.arange(n) + 0.5)
        zc = -m.h / 2 + dz * (np.arange(n) + 0.5)
        Y, Z = np.meshgrid(yc, zc)
        self.yc, self.zc = Y.ravel(), Z.ravel()
        self.dA = dy * dz
        self.Ac = m.b * m.h
        self.ys, self.zs = bar_layout(m)
        self.As_bar = np.pi * m.phi_l ** 2 / 4
        self.As = self.As_bar * len(self.ys)
        self.corners = np.array([[-m.b / 2, -m.h / 2], [m.b / 2, -m.h / 2],
                                 [m.b / 2, m.h / 2], [-m.b / 2, m.h / 2]])

    # ---------------------------------------------------------------- geometri
    def edge_dist(self):
        """Afstand fra betonkant til stangcentrum [mm]."""
        m = self.m
        return m.c_nom + m.phi_w + m.phi_l / 2

    def I_s(self, axis):
        """Armeringens inertimoment om betontværsnittets tyngdepunkt [mm^4] (bruges i 5.8.7.2)."""
        return self.As_bar * np.sum((self.zs if axis == "y" else self.ys) ** 2)

    # ---------------------------------------------------------------- kræfter
    def _forces(self, theta, t):
        """Vektoriseret: theta, t arrays med samme form (k,). Returnerer N [kN], My, Mz [kNm]."""
        theta = np.atleast_1d(theta)[:, None]
        t = np.atleast_1d(t)[:, None]
        c, s = np.cos(theta), np.sin(theta)
        s_cor = self.corners[:, 0] * c + self.corners[:, 1] * s
        s_max, s_min = s_cor.max(axis=1, keepdims=True), s_cor.min(axis=1, keepdims=True)
        s_c = self.yc * c + self.zc * s
        s_s = self.ys * c + self.zs * s
        s_b = s_s.min(axis=1, keepdims=True)
        H = s_max - s_min
        cc, st = self.conc, self.steel

        # Tøjningslinjen som to punkter (s1, e1), (s2, e2) for hvert område
        uA = np.clip(t, 0, 1)
        uB = np.clip(t - 1, 0, 1)
        uC = np.clip(t - 2, 0, 1)
        eb_end = cc.eps_cu2 * (s_b - s_min) / H
        s_C = s_max - (1 - cc.eps_c2 / cc.eps_cu2) * H
        inA, inB = t <= 1, (t > 1) & (t <= 2)
        s1 = np.where(inA, s_b, np.where(inB, s_max, s_C))
        e1 = np.where(inA, -st.eps_ud, np.where(inB, cc.eps_cu2, cc.eps_c2))
        s2 = np.where(inA, s_max, np.where(inB, s_b, s_min))
        e2 = np.where(inA, -st.eps_ud + uA * (st.eps_ud + cc.eps_cu2),
                      np.where(inB, -st.eps_ud + uB * (st.eps_ud + eb_end), uC * cc.eps_c2))
        k = (e2 - e1) / (s2 - s1)
        eps_c = e1 + k * (s_c - s1)
        eps_s = e1 + k * (s_s - s1)
        Fc = cc.stress(eps_c) * self.dA
        Fs = (st.stress(eps_s) - cc.stress(eps_s)) * self.As_bar     # fortrængt beton fratrukket
        N = Fc.sum(1) + Fs.sum(1)
        My = Fc @ self.zc + Fs @ self.zs
        Mz = Fc @ self.yc + Fs @ self.ys
        return N / 1e3, My / 1e6, Mz / 1e6

    def N_limits(self):
        """(N_min, N_max) [kN]: rent træk og rent tryk (eps_c2 over hele tværsnittet, 6.1(5))."""
        N = self._forces(np.array([0.0, 0.0]), np.array([0.0, 3.0]))[0]
        return float(N[0]), float(N[1])

    def at_N(self, thetas, N_target, iters=45):
        """Bisektion i t for alle theta samtidig. Returnerer (My, Mz) arrays [kNm]."""
        thetas = np.atleast_1d(thetas).astype(float)
        lo = np.zeros_like(thetas)
        hi = np.full_like(thetas, 3.0)
        for _ in range(iters):
            mid = 0.5 * (lo + hi)
            Nm = self._forces(thetas, mid)[0]
            low = Nm < N_target
            lo = np.where(low, mid, lo)
            hi = np.where(low, hi, mid)
        _, My, Mz = self._forces(thetas, 0.5 * (lo + hi))
        return My, Mz

    # ---------------------------------------------------------------- M-N-kurve
    def MN_curve(self, theta, n=121):
        """Hele M-N-kurven for én retning: (N, My, Mz) for t fra 0 til 3."""
        t = np.linspace(0, 3, n)
        return self._forces(np.full_like(t, theta), t)


def bar_layout(m):
    """Stangcentre (y, z): n_top i top, n_bot i bund, n_side pr. side imellem."""
    a = m.c_nom + m.phi_w + m.phi_l / 2
    y_e, z_e = m.b / 2 - a, m.h / 2 - a
    if y_e <= 0 or z_e <= 0:
        raise ValueError("Armeringen ligger uden for tværsnittet (tjek b, h, c_nom, Ø).")
    if m.n_top < 2 or m.n_bot < 2:
        raise ValueError("n_top og n_bot skal være mindst 2 (hjørnestænger).")
    ys, zs = [], []
    for y in np.linspace(-y_e, y_e, m.n_top):
        ys.append(y); zs.append(z_e)
    for y in np.linspace(-y_e, y_e, m.n_bot):
        ys.append(y); zs.append(-z_e)
    if m.n_side > 0:
        for z in np.linspace(-z_e, z_e, m.n_side + 2)[1:-1]:
            ys += [-y_e, y_e]; zs += [z, z]
    # Fri afstand mellem stænger (8.2(2)) - kun kontrol af at stængerne kan være der
    for n, w in ((m.n_top, 2 * y_e), (m.n_bot, 2 * y_e)):
        if w / (n - 1) - m.phi_l < max(m.phi_l, 20.0) - 1e-9:
            raise ValueError("For lille fri afstand mellem stængerne (8.2(2)).")
    return np.array(ys), np.array(zs)


class Contour:
    """My-Mz-kurve ved konstant N (vandret snit gennem interaktionsfladen)."""

    def __init__(self, sec, N, n_theta=72):
        th = np.linspace(-np.pi, np.pi, n_theta, endpoint=False)
        # Tæt opløsning omkring akserne, så de uniaksiale bæreevner bliver præcise
        th = np.unique(np.concatenate([th, [-np.pi / 2, 0.0, np.pi / 2, np.pi]]))
        My, Mz = sec.at_N(th, N)
        self.N, self.My, self.Mz = N, My, Mz
        psi = np.arctan2(Mz, My)
        o = np.argsort(psi)
        self._psi, self._r = psi[o], np.hypot(My, Mz)[o]
        # Uniaksiale bæreevner direkte (theta = ±90° giver rent M_y pga. symmetri om z-aksen)
        Myp, _ = sec.at_N(np.array([np.pi / 2]), N)
        Mym, _ = sec.at_N(np.array([-np.pi / 2]), N)
        self.M_Rdy_pos, self.M_Rdy_neg = float(Myp[0]), float(-Mym[0])
        self.M_Rdz_pos = float(self.radius(np.pi / 2))
        self.M_Rdz_neg = float(self.radius(-np.pi / 2))

    def radius(self, psi):
        p = np.concatenate([self._psi - 2 * np.pi, self._psi, self._psi + 2 * np.pi])
        r = np.tile(self._r, 3)
        return np.interp(np.mod(np.asarray(psi) + np.pi, 2 * np.pi) - np.pi, p, r)

    def M_Rdy(self, sign):
        return self.M_Rdy_pos if sign >= 0 else self.M_Rdy_neg

    def M_Rdz(self, sign):
        return self.M_Rdz_pos if sign >= 0 else self.M_Rdz_neg
