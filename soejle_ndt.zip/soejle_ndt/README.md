# soejle_ndt – eftervisning af simpelt understøttet betonsøjle med NDT-usikkerheder

**Ejer:** Christian (cpp@sj.dk) – Diplomprojekt DTU, *NDT-informeret vurdering af eksisterende betonelementer til genbrug*.
Den, der bruger/videreudvikler koden, ejer og vedligeholder den. Resultater skal kontrolleres fagligt.

## Hvad programmet gør
En rektangulær, simpelt understøttet søjle (l0 = L) eftervises for de lastsager, der står i `soejle_ndt/model.py`.
For hver lastsag beregnes følgende udnyttelser, og den største er styrende:

| Check | Indhold | EN 1992-1-1 |
|---|---|---|
| `U_N` | N_Ed / N_Rd,max (rent tryk) | 6.1(5) |
| `U_My`, `U_Mz` | M-N-tværsnitsbæreevne om hver akse ved N_Ed, med M_Ed inkl. imperfektion og 2. orden | 6.1, 5.2, 5.8.7 |
| `U_biax` | Biaksial bøjning, (M_Edz/M_Rdz)^a + (M_Edy/M_Rdy)^a ≤ 1; udnyttelse = sum^(1/a) | 5.8.9 |
| `U_Vz`, `U_Vy` | Forskydning ved understøtning, V_Ed = qL/2 | 6.2.2, 6.2.3 |

Lastsager (`LoadCase`): N med excentricitet e_y/e_z (ens i top og bund), N + excentricitet + jævnt fordelt tværlast
q_y/q_z, og kun tværlast (N = 0, bjælke). Der kan tilføjes flere.

### Metoder
* **Tværsnit:** fiberinddelt beton (parabel-rektangel, (3.17)), bilineært stål med vandret gren, fortrængt beton
  fratrukket, brudtøjninger iht. 6.1(3) i vilkårlig nullinjeretning. Giver M-N-kurver og My-Mz-kurver ved konstant N.
* **Imperfektion:** e_i = θ_i·l0/2, θ_i = θ_0·α_h, α_m = 1 (5.2(5), (7)). Ved biaksial bøjning kun i den mest
  ugunstige retning (5.8.9(2)): begge muligheder regnes, og den værste bruges.
* **Slankhedsgrænse:** λ_lim = 20·A·B·C/√n (5.13N) med A = 1/(1+0,2φ_ef), C = 0,7 (r_m = 1). Er λ < λ_lim,
  negligeres 2. orden (kan slås fra med `ignore_2nd_below_lim`).
* **2. orden, nominel stivhed (5.8.7):** EI = K_c E_cd I_c + K_s E_s I_s med K_s = 1, K_c = k1·k2/(1+φ_ef) (5.22),
  N_B = π²EI/l0². Forstørrelse (5.28) pr. momentkomponent: β = π²/c0 med c0 = 8 (konstant N·e),
  c0 = 9,6 (parabolsk qL²/8) og β = 1 (sinusformet imperfektion). Komponenterne lægges sammen.
* **Minimumsexcentricitet:** M_Ed ≥ N·e0, e0 = max(h/30; 20 mm) (6.1(4)) i den retning, hvor imperfektionen virker.
  Slås fra med `apply_e0_min = False`.
* **Forskydning:** V_Rd = max(V_Rd,c ; min(V_Rd,s ; V_Rd,max)) med cot θ optimeret i [1 ; 2,5]. Bøjlesnit angives
  separat for hver retning (`n_legs_z`, `n_legs_y`).

## Monte Carlo (`run_mc.py`)
De fire NDT-parametre trækkes fra fordelinger, hvor centralværdien er den målte værdi og spredningen er
måleusikkerheden:

| Parameter | Felt | Typisk kilde |
|---|---|---|
| Betonens trykstyrke | `fck` | RH/UPV kalibreret mod kerner (DS/EN 13791) |
| Længdearmeringens diameter | `phi_l` | GPR |
| Bøjlediameter | `phi_w` | GPR |
| Dæklag | `c_nom` | GPR / covermeter |

Fordelinger: `normal` (kan trunkeres), `lognormal`, `uniform`, `discrete`, `fixed`.
**De indtastede værdier er eksempler** og skal begrundes med kalibrering, producentdata og litteratur.

Output: statistik pr. check og lastsag (middel, spredning, 5/50/95 %-fraktil, P(U > 1)), Spearman-rangkorrelation
(hvilken parameter styrer variationen), OAT-tornado (hver parameter ved 5 % og 95 %-fraktil) og konvergens.

**Fortolkning:** Med regningsværdier (γ_c, γ_s) er P(U > 1) sandsynligheden for, at søjlen **ikke kan eftervises**
pga. måleusikkerheden. Det er ikke en brudsandsynlighed, for sikkerheden ligger allerede i γ-faktorerne.

## Kørsel
```bash
pip install -r requirements.txt
python main.py              # deterministisk eftervisning af referencen
python run_mc.py            # Monte Carlo (1000 trækninger ≈ 3-4 min)
python -m pytest -q tests   # kontrol mod håndberegninger
```

## Output (`resultater/`, overskrives ved hver kørsel)
| Fil | Indhold |
|---|---|
| `eftervisning.txt` | Alle mellemregninger og udnyttelser pr. lastsag |
| `MN_om_y.png`, `MN_om_z.png` | M-N-diagram med lastpunkter, 1. orden → inkl. 2. orden |
| `biaksial_MyMz.png` | My-Mz-kurver ved N_Ed: eksakt og EC2 (5.39) med lastpunkter |
| `tvaersnit.png` | Skitse af tværsnittet |
| `montecarlo.xlsx` | Input, reference, opsummering, Spearman, OAT, alle trækninger |
| `mc_histogrammer.png`, `oat_tornado.png`, `mc_spearman.png`, `mc_scatter.png`, `mc_konvergens.png` | MC-figurer |

## Verifikation (`tests/`)
Håndberegninger for referencen: N_Rd,max og rent træk, M_Rd ved N = 0 (rektangulær blok, < 2 %), usymmetrisk
armering, imperfektion og α_h-grænse, λ_lim, EI og N_B (5.21–5.22), momentforstørrelsen (5.28), e0,min,
V_Rd,c og V_Rd,s, eksponent a, uniaksial last i biaksial check, EC2 (5.39) mod eksakt kurve, MC-fordelinger og
ugyldig geometri.

## Antagelser og begrænsninger (skal vurderes fagligt)
* EC2 **anbefalede** værdier (γ_c = 1,5, γ_s = 1,15, γ_cE = 1,2, α_cc = 1,0, θ_0 = 1/200, C_Rd,c = 0,18/γ_c,
  ν = 0,6(1 − f_ck/250)). **DK NA skal tjekkes.** Klausulhenvisninger er til EN 1992-1-1:2004 – tjek mod FU2021.
* Partialkoefficienter for eksisterende konstruktioner (DS 11990) er ikke indarbejdet.
* φ_ef er input (5.8.4) og skal bestemmes ud fra lastens langtidsandel. Den kan sættes pr. lastsag.
* (5.22) forudsætter ρ ≥ 0,002 (rapporten advarer, hvis det ikke er opfyldt).
* Superposition af forstørrede momentkomponenter med hver deres c0 er en fortolkning af 5.8.7.3. Alternativet er
  β = 1 eller en ækvivalent c0.
* e0,min anvendes kun i imperfektionens retning. 5.8.9(3) normerer excentriciteterne som (e_y/b)/(e_z/h) –
  betegnelserne i (5.38b) skal tjekkes.
* Forskydning eftervises for hver retning for sig. Minimumsarmering, bøjleafstand (9.5.3) og forankring er ikke
  kontrolleret. Fri stangafstand (8.2(2)) bruges kun til at afvise umulige geometrier.
* Ingen betontræk, stålhærdning, omslutning eller korrosion. Kun ens diameter for alle længdestænger.
* Dæklaget er kun en geometrisk parameter (holdbarhed er afgrænset).

## Kode og data
Skal koden deles med andre i SJ eller bruges efter projektet, hører den i SJ's GitHub
(github.com/SorenJensen-AS) som privat repo med denne README. Læg ikke kundedata eller nøgler i repoet.
