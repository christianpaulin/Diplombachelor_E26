"""Kontrol mod håndberegninger. Referencetal er regnet i hånden for Model() (300x300, 6Ø16, C30, L = 4 m)."""
import dataclasses

import numpy as np
import pytest

from soejle_ndt.model import Model, LoadCase
from soejle_ndt.section import Section, Contour
from soejle_ndt.second_order import imperfection, lambda_lim, nominal_stiffness, design_moment
from soejle_ndt.shear import shear_capacity
from soejle_ndt.checks import run, exponent_a
from soejle_ndt import montecarlo as mc

m0 = Model()


def test_rent_tryk_og_traek():
    sec = Section(m0)
    N_min, N_max = sec.N_limits()
    sig_s = min(sec.steel.fyd, m0.Es * 2e-3) - sec.conc.fcd
    assert N_max == pytest.approx((sec.Ac * sec.conc.fcd + sec.As * sig_s) / 1e3, rel=5e-3)
    assert N_min == pytest.approx(-sec.As * sec.steel.fyd / 1e3, rel=1e-6)


def test_MRd_ren_boejning_haandberegning():
    # 3Ø16 = 603 mm², fyd = 478,3, d = 300-30-8-8 = 254, x = As fyd / (0,8 b fcd) = 60,1 mm
    # M = As fyd (d - 0,4x) = 66,3 kNm (rektangulær blok, trykarmering negligeret)
    con = Contour(Section(m0), 0.0)
    assert con.M_Rdy(+1) == pytest.approx(66.3, rel=0.02)


def test_usymmetrisk_armering():
    con = Contour(Section(dataclasses.replace(m0, n_top=2, n_bot=4)), 0.0)
    assert con.M_Rdy(+1) > 1.3 * con.M_Rdy(-1)       # tryk i top -> 4 stænger i træk


def test_imperfektion():
    e_i, th = imperfection(m0)                         # alpha_h = 2/sqrt(4) = 1
    assert th == pytest.approx(1 / 200) and e_i == pytest.approx(10.0)
    e_i, th = imperfection(dataclasses.replace(m0, L=16000))   # alpha_h = 0,5 -> 2/3
    assert th == pytest.approx(1 / 300)


def test_lambda_lim():
    # n = 0,5; omega = 0,320; A = 0,833; B = 1,282; C = 0,7 -> 21,14
    assert lambda_lim(m0, Section(m0), 900.0, 1.0) == pytest.approx(21.14, rel=2e-3)


def test_nominel_stivhed_og_forstoerrelse():
    sec = Section(m0)
    EI, d = nominal_stiffness(m0, sec, "y", 900.0, 1.0)
    # k1 = 1,2247; k2 = 0,5*46,19/170 = 0,1359; Kc = 0,0832; Ecd = 27364; Ic = 6,75e8; Is = 1,304e7
    assert EI == pytest.approx(4.146e12, rel=3e-3)
    NB = np.pi ** 2 * EI / m0.L ** 2 / 1e3
    assert NB == pytest.approx(2557.6, rel=3e-3)
    M, dd = design_moment(m0, sec, m0.load_cases[0], "y", True, 1.0)
    # M0e = 27 kNm * (1 + 1,2337/(NB/N - 1)) + 9 kNm * (1 + 1/(NB/N - 1))
    f = 1 / (NB / 900 - 1)
    assert M == pytest.approx(27 * (1 + np.pi ** 2 / 8 * f) + 9 * (1 + f), rel=1e-6)


def test_e0_min():
    m = dataclasses.replace(m0, load_cases=[LoadCase("c", N=500.0)], L=1000.0)   # kort søjle
    M, d = design_moment(m, Section(m), m.load_cases[0], "y", True, 1.0)
    assert d["e0_governs"] and M == pytest.approx(500 * 20 / 1e3)


def test_forskydning_haandberegning():
    sec = Section(m0)
    V, d = shear_capacity(m0, sec, "y", 0.0, +1)
    # V_Rd,c = 0,12*1,887*(100*0,00791*30)^(1/3)*300*254 = 49,6 kN
    assert d["V_Rdc"] == pytest.approx(49.6, rel=5e-3)
    # V_Rd,s = 100,5/200 * 228,6 * 478,3 * 2,5 = 137,3 kN
    assert d["V_Rds"] == pytest.approx(137.3, rel=5e-3)


def test_eksponent_a():
    assert exponent_a(0.05, 1) == 1.0
    assert exponent_a(0.4, 1) == pytest.approx(1.25)
    assert exponent_a(1.0, 1) == pytest.approx(2.0)


def test_uniaksial_last_biaksial_lig_uniaksial():
    _, res = run(m0)
    r = res[2]                                         # LC3: kun q_z
    assert r["U_biax"] == pytest.approx(r["U_My"], rel=1e-6)
    assert r["U_My"] == pytest.approx(40.0 / r["M_Rdy"], rel=1e-6)


def test_biaksial_konservativ_mod_eksakt():
    _, res = run(m0)
    for r in res[:2]:
        assert r["biax"]["U"] >= r["biax"]["U_exact"] * 0.99


def test_mc_fordelinger():
    rng = np.random.default_rng(0)
    x = mc.sample({"dist": "lognormal", "mean": 30, "std": 4}, 200_000, rng)
    assert x.mean() == pytest.approx(30, rel=5e-3) and x.std() == pytest.approx(4, rel=2e-2)
    y = mc.sample({"dist": "normal", "mean": 30, "std": 5, "lo": 25}, 10_000, rng)
    assert y.min() >= 25


def test_mc_ugyldig_geometri():
    assert mc.evaluate(m0, {"c_nom": 200.0}) is None
