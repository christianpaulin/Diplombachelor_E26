"""Deterministisk eftervisning af referencesøjlen i soejle_ndt/model.py.

    python main.py
Resultater i ./resultater (overskrives).
"""
from pathlib import Path

from soejle_ndt.model import Model
from soejle_ndt.checks import run
from soejle_ndt import plotting, report


def main(m=None, out="resultater"):
    m = m or Model()
    out = Path(out); out.mkdir(exist_ok=True)
    sec, res = run(m)
    txt = report.text(m, sec, res)
    (out / "eftervisning.txt").write_text(txt, encoding="utf-8")
    print(txt)
    plotting.section(sec, out / "tvaersnit.png")
    plotting.mn_diagram(sec, res, "y", out / "MN_om_y.png")
    plotting.mn_diagram(sec, res, "z", out / "MN_om_z.png")
    plotting.biaxial(sec, res, m, out / "biaksial_MyMz.png")
    print(f"\nFigurer gemt i {out.resolve()}")
    return sec, res


if __name__ == "__main__":
    main()
